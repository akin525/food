





































































































































































































    <!DOCTYPE html>
<html lang="en">


<!-- Mirrored from quomodosoft.com/html/reservq/sign-up.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 15 Mar 2024 14:19:49 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>1303 </title>

    <!-- fave-icon  -->
    <link rel="shortcut icon" href="assets/images/icon/fave.png" type="image/png">

    <!-- font awesome cdn link  -->

    <link rel="stylesheet" href="cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">






    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/venobox.min.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>

<body>


<!-- login  -->


<div class="sign-up-top">

    <div class="sign-up-main-two">

        <div class="sign-up-main-two-item">
            <div class="sign-up-img">
                <a href="#"> <img src="assets/images/thumb/login.png" alt="img"></a>
                <div class="sign-up-main-two-item-text">
                    <p>You agree to ReservQ <span>Terms of Use & Privacy Policy.</span> You don't need to consent as
                        a condition
                        of
                        food, or buying any other goods or services. Message/data rates may apply.</p>
                </div>
            </div>


        </div>


    </div>

    <div class="sign-up-main">
        <div class="sign-up-logo">

        </div>
        <div class="sign-up-text">
            <h2>Welcome back</h2>
            <p>Welcome back! Please enter your details.</p>
        </div>


        <div class="sign-up-from">
            <div class="sign-up-from-item">

                <div class="sign-up-from-inner">
                    <label for="exampleFormControlInput1" class="form-label">Email</label>
                    <input type="email" class="form-control" id="exampleFormControlInput"
                           placeholder="hi@example.com">
                </div>
                <div class="sign-up-from-inner">
                    <label for="exampleFormControlInput1" class="form-label">Password</label>
                    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Password">

                    <div class="icon">
                            <span>
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M15.5799 12.0019C15.5799 13.9819 13.9799 15.5819 11.9999 15.5819C10.0199 15.5819 8.41992 13.9819 8.41992 12.0019C8.41992 10.0219 10.0199 8.42188 11.9999 8.42188C13.9799 8.42188 15.5799 10.0219 15.5799 12.0019Z"
                                        stroke="#9EA3AE" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                    <path
                                        d="M11.9998 20.2688C15.5298 20.2688 18.8198 18.1887 21.1098 14.5887C22.0098 13.1787 22.0098 10.8087 21.1098 9.39875C18.8198 5.79875 15.5298 3.71875 11.9998 3.71875C8.46984 3.71875 5.17984 5.79875 2.88984 9.39875C1.98984 10.8087 1.98984 13.1787 2.88984 14.5887C5.17984 18.1887 8.46984 20.2688 11.9998 20.2688Z"
                                        stroke="#9EA3AE" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </span>
                    </div>
                </div>

                <div class="sign-up-from-inner">

                    <div class="sign-up-from-df">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="gridCheck">
                            <label class="form-check-label" for="gridCheck">
                                Remember me

                            </label>
                        </div>

                        <div class="sign-up-main-btn">
                            <button type="button" class="modal-sign-up-from-btn" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal-4" data-bs-dismiss="modal">
                                Forgot Password?
                            </button>
                            <!-- Modal -->




                            <div class="modal fade" id="exampleModal-4" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-six">
                                    <div class="modal-content modal-content-three ">
                                        <div class="modal-body">


                                            <div class="modal-sign-up-logo">



                                                <button class="modal-close" data-bs-dismiss="modal"
                                                        aria-label="Close">
                                                        <span>
                                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                                 xmlns="http://www.w3.org/2000/svg">
                                                                <path
                                                                    d="M16.2427 7.75786L7.75739 16.2431M16.2427 16.2431L7.75739 7.75781"
                                                                    stroke="#F01543" stroke-width="1.5"
                                                                    stroke-linecap="round" stroke-linejoin="round" />
                                                            </svg>
                                                        </span>
                                                </button>


                                            </div>
                                            <div class="modal-sign-up-text">
                                                <h2>Reset your password</h2>
                                                <p>Enter the email address associated with your account and we'll
                                                    send you a link to reset your password.</p>

                                            </div>


                                            <div class="modal-sign-up-from">
                                                <input type="email" class="form-control"
                                                       id="exampleFormControlInput2" placeholder="onamsarker@mail.com">
                                            </div>

                                            <div class="modal-sign-up-from-btn-two">
                                                <a href="<?php echo e(route('login')); ?>">Return to login</a>
                                            </div>


                                            <div class="btn-one-modal">
                                                <button type="button" class=" main-btn-four " data-bs-toggle="modal"
                                                        data-bs-target="#exampleModal-5" data-bs-dismiss="modal">
                                                    Continue

                                                    <span>
                                                            <svg width="15" height="15" viewBox="0 0 15 15" fill="none"
                                                                 xmlns="http://www.w3.org/2000/svg">
                                                                <g clip-path="url(#clip0_317_13742)">
                                                                    <path
                                                                        d="M1.41972 8.63898L11.0737 8.63898L7.30373 12.379C7.09177 12.5965 6.97314 12.8882 6.97314 13.192C6.97314 13.4957 7.09177 13.7875 7.30373 14.005C7.51841 14.217 7.80799 14.3359 8.10973 14.3359C8.41146 14.3359 8.70105 14.217 8.91573 14.005L14.6477 8.305C14.8528 8.0869 14.9669 7.79885 14.9669 7.49951C14.9669 7.20018 14.8528 6.91207 14.6477 6.69397L8.91573 0.993959C8.70105 0.781929 8.41146 0.663087 8.10973 0.663087C7.80799 0.663087 7.51841 0.781928 7.30373 0.993959C7.09659 1.20969 6.97748 1.49504 6.96973 1.79401C6.97267 2.09575 7.09238 2.3846 7.30373 2.59998L11.0737 6.35498L1.41972 6.35498C1.12309 6.36377 0.84155 6.48776 0.634836 6.70068C0.428121 6.91361 0.312501 7.19872 0.312501 7.49548C0.312501 7.79225 0.428121 8.07736 0.634835 8.29028C0.84155 8.50321 1.12309 8.6272 1.41972 8.63599L1.41972 8.63898Z"
                                                                        fill="white" />
                                                                </g>
                                                            </svg>
                                                        </span>
                                                </button>
                                            </div>



                                        </div>





                                    </div>
                                </div>
                            </div>


                            <div class="modal fade" id="exampleModal-5" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-six">
                                    <div class="modal-content">

                                        <div class="modal-body">
                                            <div class="modal-sign-up-text">
                                                <h2>Enter verification code</h2>
                                                <p>We have just sent a verification code to ajoy*****@mail.com</p>
                                            </div>


                                            <div class="modal-sign-up-from modal-sign-up-from-two ">
                                                <input type="email" class="form-control"
                                                       id="exampleFormControlInput4">
                                                <input type="email" class="form-control"
                                                       id="exampleFormControlInput5">
                                                <input type="email" class="form-control"
                                                       id="exampleFormControlInput6">
                                                <input type="email" class="form-control"
                                                       id="exampleFormControlInput7">
                                            </div>

                                            <div class="modal-sign-up-from-btn-two">
                                                <a href="#">Send the code again</a>
                                            </div>


                                            <div class="btn-one-modal">
                                                <button type="button" class=" main-btn-four " data-bs-toggle="modal"
                                                        data-bs-target="#exampleModal-6" data-bs-dismiss="modal">
                                                    Continue

                                                    <span>
                                                            <svg width="15" height="15" viewBox="0 0 15 15" fill="none"
                                                                 xmlns="http://www.w3.org/2000/svg">
                                                                <g clip-path="url(#clip0_317_13742)">
                                                                    <path
                                                                        d="M1.41972 8.63898L11.0737 8.63898L7.30373 12.379C7.09177 12.5965 6.97314 12.8882 6.97314 13.192C6.97314 13.4957 7.09177 13.7875 7.30373 14.005C7.51841 14.217 7.80799 14.3359 8.10973 14.3359C8.41146 14.3359 8.70105 14.217 8.91573 14.005L14.6477 8.305C14.8528 8.0869 14.9669 7.79885 14.9669 7.49951C14.9669 7.20018 14.8528 6.91207 14.6477 6.69397L8.91573 0.993959C8.70105 0.781929 8.41146 0.663087 8.10973 0.663087C7.80799 0.663087 7.51841 0.781928 7.30373 0.993959C7.09659 1.20969 6.97748 1.49504 6.96973 1.79401C6.97267 2.09575 7.09238 2.3846 7.30373 2.59998L11.0737 6.35498L1.41972 6.35498C1.12309 6.36377 0.84155 6.48776 0.634836 6.70068C0.428121 6.91361 0.312501 7.19872 0.312501 7.49548C0.312501 7.79225 0.428121 8.07736 0.634835 8.29028C0.84155 8.50321 1.12309 8.6272 1.41972 8.63599L1.41972 8.63898Z"
                                                                        fill="white" />
                                                                </g>
                                                            </svg>
                                                        </span>
                                                </button>
                                            </div>

                                        </div>




                                    </div>
                                </div>
                            </div>


                            <div class="modal fade" id="exampleModal-6" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-six">
                                    <div class="modal-content">
                                        <div class="modal-body">

                                            <div class="modal-sign-up-text">
                                                <h2>Create new password</h2>
                                                <p>Please enter a new password. Your new password must be different
                                                    from previous password.</p>
                                            </div>


                                            <div class="password-from-item">
                                                <div class="password-from-inner">
                                                    <input type="password" class="form-control form-control-two"
                                                           id="exampleFormControlInput9" placeholder=" ********">

                                                    <div class="eye-icon">
                                                            <span>
                                                                <svg width="36" height="25" viewBox="0 0 36 25"
                                                                     fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path opacity="0.4" d="M34.6172 5.5V18.5"
                                                                          stroke="#96A3BE" stroke-linecap="round" />
                                                                    <path
                                                                        d="M12.9316 22.1328C7.40864 22.1328 2.93164 17.6558 2.93164 12.1328C2.93164 6.60981 7.40864 2.13281 12.9316 2.13281C18.4546 2.13281 22.9316 6.60981 22.9316 12.1328C22.9316 17.6558 18.4546 22.1328 12.9316 22.1328ZM12.9316 20.1328C15.0534 20.1328 17.0882 19.29 18.5885 17.7897C20.0888 16.2894 20.9316 14.2545 20.9316 12.1328C20.9316 10.0111 20.0888 7.97625 18.5885 6.47596C17.0882 4.97567 15.0534 4.13281 12.9316 4.13281C10.8099 4.13281 8.77508 4.97567 7.27479 6.47596C5.7745 7.97625 4.93164 10.0111 4.93164 12.1328C4.93164 14.2545 5.7745 16.2894 7.27479 17.7897C8.77508 19.29 10.8099 20.1328 12.9316 20.1328ZM11.9316 12.9248C11.4052 12.6951 10.974 12.2911 10.7104 11.7808C10.4469 11.2705 10.367 10.685 10.4844 10.1228C10.6017 9.56051 10.9091 9.05583 11.3548 8.69356C11.8005 8.33129 12.3573 8.13352 12.9316 8.13352C13.506 8.13352 14.0628 8.33129 14.5085 8.69356C14.9542 9.05583 15.2616 9.56051 15.3789 10.1228C15.4963 10.685 15.4164 11.2705 15.1529 11.7808C14.8893 12.2911 14.458 12.6951 13.9316 12.9248V16.1328H11.9316V12.9248Z"
                                                                        fill="#96A3BE" />
                                                                </svg>
                                                            </span>
                                                    </div>
                                                </div>
                                                <div class="password-from-inner">
                                                    <input type="password" class="form-control form-control-two"
                                                           id="exampleFormControlInput10" placeholder="Re- Password">

                                                    <div class="eye-icon">
                                                            <span>
                                                                <svg width="36" height="25" viewBox="0 0 36 25"
                                                                     fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path opacity="0.4" d="M34.6172 5.5V18.5"
                                                                          stroke="#96A3BE" stroke-linecap="round" />
                                                                    <path
                                                                        d="M12.9316 22.1328C7.40864 22.1328 2.93164 17.6558 2.93164 12.1328C2.93164 6.60981 7.40864 2.13281 12.9316 2.13281C18.4546 2.13281 22.9316 6.60981 22.9316 12.1328C22.9316 17.6558 18.4546 22.1328 12.9316 22.1328ZM12.9316 20.1328C15.0534 20.1328 17.0882 19.29 18.5885 17.7897C20.0888 16.2894 20.9316 14.2545 20.9316 12.1328C20.9316 10.0111 20.0888 7.97625 18.5885 6.47596C17.0882 4.97567 15.0534 4.13281 12.9316 4.13281C10.8099 4.13281 8.77508 4.97567 7.27479 6.47596C5.7745 7.97625 4.93164 10.0111 4.93164 12.1328C4.93164 14.2545 5.7745 16.2894 7.27479 17.7897C8.77508 19.29 10.8099 20.1328 12.9316 20.1328ZM11.9316 12.9248C11.4052 12.6951 10.974 12.2911 10.7104 11.7808C10.4469 11.2705 10.367 10.685 10.4844 10.1228C10.6017 9.56051 10.9091 9.05583 11.3548 8.69356C11.8005 8.33129 12.3573 8.13352 12.9316 8.13352C13.506 8.13352 14.0628 8.33129 14.5085 8.69356C14.9542 9.05583 15.2616 9.56051 15.3789 10.1228C15.4963 10.685 15.4164 11.2705 15.1529 11.7808C14.8893 12.2911 14.458 12.6951 13.9316 12.9248V16.1328H11.9316V12.9248Z"
                                                                        fill="#96A3BE" />
                                                                </svg>
                                                            </span>
                                                    </div>



                                                </div>
                                            </div>

                                            <div class="btn-one-modal">
                                                <button type="button" class=" main-btn-four " data-bs-toggle="modal"
                                                        data-bs-target="#exampleModal-7" data-bs-dismiss="modal">
                                                    Continue

                                                    <span>
                                                            <svg width="15" height="15" viewBox="0 0 15 15" fill="none"
                                                                 xmlns="http://www.w3.org/2000/svg">
                                                                <g clip-path="url(#clip0_317_13742)">
                                                                    <path
                                                                        d="M1.41972 8.63898L11.0737 8.63898L7.30373 12.379C7.09177 12.5965 6.97314 12.8882 6.97314 13.192C6.97314 13.4957 7.09177 13.7875 7.30373 14.005C7.51841 14.217 7.80799 14.3359 8.10973 14.3359C8.41146 14.3359 8.70105 14.217 8.91573 14.005L14.6477 8.305C14.8528 8.0869 14.9669 7.79885 14.9669 7.49951C14.9669 7.20018 14.8528 6.91207 14.6477 6.69397L8.91573 0.993959C8.70105 0.781929 8.41146 0.663087 8.10973 0.663087C7.80799 0.663087 7.51841 0.781928 7.30373 0.993959C7.09659 1.20969 6.97748 1.49504 6.96973 1.79401C6.97267 2.09575 7.09238 2.3846 7.30373 2.59998L11.0737 6.35498L1.41972 6.35498C1.12309 6.36377 0.84155 6.48776 0.634836 6.70068C0.428121 6.91361 0.312501 7.19872 0.312501 7.49548C0.312501 7.79225 0.428121 8.07736 0.634835 8.29028C0.84155 8.50321 1.12309 8.6272 1.41972 8.63599L1.41972 8.63898Z"
                                                                        fill="white" />
                                                                </g>
                                                            </svg>
                                                        </span>
                                                </button>
                                            </div>



                                        </div>




                                    </div>
                                </div>
                            </div>

                            <div class="modal fade" id="exampleModal-7" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-six">
                                    <div class="modal-content">
                                        <div class="modal-body">


                                            <div class="modal-sign-up-img  ">
                                                <img src="assets/images/small/modal-imf-7.png" alt="logo">
                                            </div>
                                            <div class="modal-sign-up-text sign-up-text-to  ">
                                                <h2>Your successfully changed your password</h2>
                                                <p>Setting up an account takes less than 1 minute.
                                                </p>
                                            </div>




                                            <div class="btn-one-modal">
                                                <button type="button" class=" main-btn-four "
                                                        data-bs-dismiss="modal">
                                                    Continue

                                                    <span>
                                                            <svg width="15" height="15" viewBox="0 0 15 15" fill="none"
                                                                 xmlns="http://www.w3.org/2000/svg">
                                                                <g clip-path="url(#clip0_317_13742)">
                                                                    <path
                                                                        d="M1.41972 8.63898L11.0737 8.63898L7.30373 12.379C7.09177 12.5965 6.97314 12.8882 6.97314 13.192C6.97314 13.4957 7.09177 13.7875 7.30373 14.005C7.51841 14.217 7.80799 14.3359 8.10973 14.3359C8.41146 14.3359 8.70105 14.217 8.91573 14.005L14.6477 8.305C14.8528 8.0869 14.9669 7.79885 14.9669 7.49951C14.9669 7.20018 14.8528 6.91207 14.6477 6.69397L8.91573 0.993959C8.70105 0.781929 8.41146 0.663087 8.10973 0.663087C7.80799 0.663087 7.51841 0.781928 7.30373 0.993959C7.09659 1.20969 6.97748 1.49504 6.96973 1.79401C6.97267 2.09575 7.09238 2.3846 7.30373 2.59998L11.0737 6.35498L1.41972 6.35498C1.12309 6.36377 0.84155 6.48776 0.634836 6.70068C0.428121 6.91361 0.312501 7.19872 0.312501 7.49548C0.312501 7.79225 0.428121 8.07736 0.634835 8.29028C0.84155 8.50321 1.12309 8.6272 1.41972 8.63599L1.41972 8.63898Z"
                                                                        fill="white" />
                                                                </g>
                                                            </svg>
                                                        </span>
                                                </button>
                                            </div>



                                        </div>



                                    </div>
                                </div>
                            </div>



                        </div>









                    </div>


                </div>

                <div class="sign-up-btn">
                    <div class="main-btn-four">
                        <a href="index.html">Sign Up</a>
                    </div>
                    <div class="sign-up-btn-two">
                        <a href="#"> <span><svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M21.8055 10.0415H21V10H12V14H17.6515C16.827 16.3285 14.6115 18 12 18C8.6865 18 6 15.3135 6 12C6 8.6865 8.6865 6 12 6C13.5295 6 14.921 6.577 15.9805 7.5195L18.809 4.691C17.023 3.0265 14.634 2 12 2C6.4775 2 2 6.4775 2 12C2 17.5225 6.4775 22 12 22C17.5225 22 22 17.5225 22 12C22 11.3295 21.931 10.675 21.8055 10.0415Z"
                                            fill="#FFC107" />
                                        <path
                                            d="M3.15283 7.3455L6.43833 9.755C7.32733 7.554 9.48033 6 11.9998 6C13.5293 6 14.9208 6.577 15.9803 7.5195L18.8088 4.691C17.0228 3.0265 14.6338 2 11.9998 2C8.15883 2 4.82783 4.1685 3.15283 7.3455Z"
                                            fill="#FF3D00" />
                                        <path
                                            d="M12.0002 22.0003C14.5832 22.0003 16.9302 21.0118 18.7047 19.4043L15.6097 16.7853C14.5719 17.5745 13.3039 18.0014 12.0002 18.0003C9.39916 18.0003 7.19066 16.3418 6.35866 14.0273L3.09766 16.5398C4.75266 19.7783 8.11366 22.0003 12.0002 22.0003Z"
                                            fill="#4CAF50" />
                                        <path
                                            d="M21.8055 10.0415H21V10H12V14H17.6515C17.2571 15.1082 16.5467 16.0766 15.608 16.7855L15.6095 16.7845L18.7045 19.4035C18.4855 19.6025 22 17 22 12C22 11.3295 21.931 10.675 21.8055 10.0415Z"
                                            fill="#1976D2" />
                                    </svg></span> Contiue with Google</a>
                    </div>


                    <p>Don’t have an account? <a href="sign-up.html">Sign up for free</a></p>

                </div>
            </div>
        </div>

    </div>


</div>





<!-- login  -->



<script src="assets/js/jquery-3.6.3.min.js"></script>
<script src="assets/js/venobox.min.js"></script>
<script src="assets/js/aos.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/jquery.shuffle.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/custom.js"></script>







</body>


<!-- Mirrored from quomodosoft.com/html/reservq/sign-up.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 15 Mar 2024 14:19:49 GMT -->
</html>
<?php /**PATH C:\Users\DELL\PhpstormProjects\food\resources\views/auth/register.blade.php ENDPATH**/ ?>